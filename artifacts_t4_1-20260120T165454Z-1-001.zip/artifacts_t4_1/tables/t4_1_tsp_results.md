## TSP50

| algorithm | greedy cost (mean±std) | best-of-k cost (mean±std) |
|---|---:|---:|
| `pomo` | 6.4455 ± 0.0496 | 5.9814 ± 0.0051 |
| `leader_reward` | 6.5286 ± 0.0546 | 6.0122 ± 0.0137 |
| `maxk_pomo` | 6.7292 ± 0.1661 | 6.2822 ± 0.0491 |

